# Adjie AI Image Generator

Website satu halaman untuk membuat gambar dan video dari prompt menggunakan Pollinations API.

## Menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser modern, atau unggah ke GitHub Pages / Netlify / Vercel.
3. Buat API key di https://enter.pollinations.ai/
4. Masukkan key pada kolom API Key di website.
5. Pilih Gambar atau Video, tulis prompt, lalu tekan Generate.

## Penting soal gratis
Website/front-end ini tidak memungut biaya. Namun pembuatan media diproses oleh layanan Pollinations dan memerlukan API key. Kuota, kredit, rate limit, watermark, model yang tersedia, dan harga dapat berubah. Tidak ada jaminan generasi tanpa batas secara gratis.

## Keamanan
- Jangan menanamkan secret API key (`sk_...`) ke file HTML yang di-host publik.
- Untuk website publik, sebaiknya buat backend/proxy sendiri dan simpan secret key sebagai environment variable.
- Versi ini meminta setiap pengunjung memasukkan key mereka sendiri di browser. Key tidak dikirim ke server milik pembuat website, tetapi tetap digunakan untuk request ke Pollinations.

## File
- `index.html` — seluruh aplikasi (HTML, CSS, JavaScript).
